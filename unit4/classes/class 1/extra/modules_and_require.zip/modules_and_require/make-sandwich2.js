module.exports = function () {
  console.log(" Making Sandwich 2");
  return "Sandwich 2";
};
