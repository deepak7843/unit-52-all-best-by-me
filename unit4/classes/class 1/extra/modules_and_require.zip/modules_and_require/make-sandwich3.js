function makeSandwich() {
  console.log(" Making Sandwich 3");
}

function makeBurger() {
  console.log(" Making Burger 3");
}

// console.log(module.exports);
// module.exports.makeSandwich = makeSandwich;
// module.exports.makeBurger = makeBurger;

module.exports = { makeSandwich, makeBurger };
