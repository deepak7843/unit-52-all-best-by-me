// const makeSandwich2 = require("./make-sandwich2");

// const makingSandwich = { task: "Making Sandwich 1" };

// function makeSandwich() {
//   console.log(makingSandwich);
//   console.log(`not Making ${makeSandwich2()}`);
// }

// makingSandwich.task = "Making Sandwich 2";
// makeSandwich();

// const makeSandwich1 = require("./make-sandwich1");
// const makeSandwich2 = require("./make-sandwich2");
// const makeSandwich3 = require("./make-sandwich3");

// makeSandwich1();
// console.log(makeSandwich1.password.task);
// makeSandwich1.password.task = "skdfhskdf";
// console.log(makeSandwich1.password);
// makeSandwich1.makeSandwich();
// makeSandwich2();
// console.log(makeSandwich3);
// makeSandwich3.makeSandwich();

// const second = require("./src/second");

// // ./src/second
// // ../second

// console.log(second);
// console.log("Hello");

// Core Modules => comes with installation of node
// Third Party Modules => what you install using npm
// User Generated Modules => code that you have written for your project

// const object = {
//   name: { firstName: "Dhaval" },
// };

// object.name = "Second";

// console.log(object);
