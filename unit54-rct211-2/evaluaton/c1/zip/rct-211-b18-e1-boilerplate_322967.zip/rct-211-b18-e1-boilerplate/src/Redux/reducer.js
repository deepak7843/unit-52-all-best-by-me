const initialState = {
  profileData: [],
  isLoading: false,
  isError: false,
};

const reducer = (oldState = initialState) => {
  return oldState;
};

export { reducer };
