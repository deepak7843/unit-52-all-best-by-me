import React from "react";

const Navbar = () => {
  return (
    <div>
      <h1>Dashboard</h1>
    </div>
  );
};

export default Navbar;
