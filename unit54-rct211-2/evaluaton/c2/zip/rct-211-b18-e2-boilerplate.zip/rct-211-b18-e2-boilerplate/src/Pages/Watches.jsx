import React from "react";
import Filter from "../Components/Filter";

const Watches = () => {
  return (
    <div>
      <Filter />
      <div>
        {/* Map through the watch list here using WatchCard Component */}
      </div>
    </div>
  );
};

export default Watches;
